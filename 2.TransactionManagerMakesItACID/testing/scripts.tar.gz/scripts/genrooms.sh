#!/bin/bash

. $SRC512_HOME/512_env

minRooms=30
maxRooms=600

minPrice=40
maxPrice=700

function printRooms()
{
	rnd=$RANDOM
  rms=$(echo "$rnd%$maxRooms+$minRooms" | bc)
	if [[ $rms -lt $minRooms ]]
	then
	  echo -e $minRooms
	elif [[ $rms -gt $maxRooms ]]
	then
	  echo -e $maxRooms
	else
	  echo -e $rms
	fi
}

function printPrice()
{
	rnd=$RANDOM
  prce=$(echo "$rnd%$maxPrice+$minPrice" | bc)
	if [[ $prce -lt $minPrice ]]
	then
	  echo -e $minPrice
	elif [[ $prce -gt $maxPrice ]]
	then
	  echo -e $maxPrice
	else
	  echo -e $prce
	fi
}

(
  echo start
  for city in $(cat ${CITY_LIST})
	do
  	echo "newroom,$city,"`printRooms`','`printPrice`
	done
  echo commit
  echo quit
) > ${GENDATADIR}/rooms.cmd
