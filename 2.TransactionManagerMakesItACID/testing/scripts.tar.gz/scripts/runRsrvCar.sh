#!/bin/bash

. $SRC512_HOME/512_env


