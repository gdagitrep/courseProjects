#!/bin/bash

. $SRC512_HOME/512_env

minCars=30
maxCars=600

minPrice=40
maxPrice=700

function printCars()
{
	rnd=$RANDOM
  rms=$(echo "$rnd%$maxCars+$minCars" | bc)
	if [[ $rms -lt $minCars ]]
	then
	  echo -e $minCars
	elif [[ $rms -gt $maxCars ]]
	then
	  echo -e $maxCars
	else
	  echo -e $rms
	fi
}

function printPrice()
{
	rnd=$RANDOM
  prce=$(echo "$rnd%$maxPrice+$minPrice" | bc)
	if [[ $prce -lt $minPrice ]]
	then
	  echo -e $minPrice
	elif [[ $prce -gt $maxPrice ]]
	then
	  echo -e $maxPrice
	else
	  echo -e $prce
	fi
}

(
  echo start
  for city in $(cat ${CITY_LIST})
	do
  	echo "newcar,$city,"`printCars`','`printPrice`
	done
  echo commit
  echo quit
) > ${GENDATADIR}/cars.cmd
