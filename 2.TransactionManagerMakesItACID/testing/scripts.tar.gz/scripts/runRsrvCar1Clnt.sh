#!/bin/bash

. $SRC512_HOME/512_env

export PROCESS_ID=CLIENT

${TESTENVDIR}/scripts/txnGenRsrvCar.sh 100 10000 20000 | ${SCRIPT_DIR}/start_client.sh | grep '^PRF' > ${TESTENVDIR}/logs/CLIENT001/client/client_1.log
